"""
PROJECTHUB - AI  |  Backend entrypoint

Run locally with:
    python -m uvicorn main:app --reload
"""

import os
from dotenv import load_dotenv
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import SQLAlchemyError

from database.connection import engine
from database.base import Base
import models  # noqa: F401  (ensures all models are registered on Base.metadata)

from routes import auth, student, faculty, admin, projects, tasks, progress, ai

load_dotenv()

app = FastAPI(
    title="PROJECTHUB - AI",
    description=(
        "Academic project management backend for PROJECTHUB - AI. "
        "Provides secure REST APIs for students, faculty and admins, "
        "including authentication, project/task/team management, "
        "progress tracking, feedback and an AI assistance module."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ------------------------------------------------------------------ #
# CORS
# ------------------------------------------------------------------ #
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ------------------------------------------------------------------ #
# Database table creation (simple init; use Alembic for real migrations)
# ------------------------------------------------------------------ #
Base.metadata.create_all(bind=engine)

# ------------------------------------------------------------------ #
# Global error handlers (never leak raw DB errors to clients)
# ------------------------------------------------------------------ #
@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_exception_handler(request: Request, exc: SQLAlchemyError):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "A database error occurred. Please try again later."},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": "Invalid request data", "errors": exc.errors()},
    )


# ------------------------------------------------------------------ #
# Routers
# ------------------------------------------------------------------ #
app.include_router(auth.router)
app.include_router(student.router)
app.include_router(faculty.router)
app.include_router(admin.router)
app.include_router(projects.router)
app.include_router(tasks.router)
app.include_router(progress.router)
app.include_router(ai.router)


@app.get("/", tags=["Health"], summary="Health check")
def root():
    return {
        "status": "ok",
        "service": "PROJECTHUB - AI backend",
        "docs": "/docs",
    }
