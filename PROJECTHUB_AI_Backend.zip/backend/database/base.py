"""
Shared declarative Base for all SQLAlchemy ORM models.
All model files import Base from here so metadata stays in one place.
"""

from sqlalchemy.orm import declarative_base

Base = declarative_base()
