from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from models.project import Project
from models.team import Team, TeamMember
from models.user import User, RoleEnum


def get_project_or_404(db: Session, project_id: int) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Project not found"
        )
    return project


def user_is_member_of_project(db: Session, user_id: int, project_id: int) -> bool:
    return (
        db.query(TeamMember)
        .join(Team, Team.id == TeamMember.team_id)
        .filter(Team.project_id == project_id, TeamMember.user_id == user_id)
        .first()
        is not None
    )


def ensure_student_can_access_project(db: Session, user: User, project: Project):
    """
    A student may access a project if they created it or are a team member.
    Faculty/Admin bypass this check (handled by the route's role dependency).
    """
    if project.created_by == user.id:
        return
    if user_is_member_of_project(db, user.id, project.id):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have access to this project",
    )
