"""
AI Service (modular).

This module isolates all AI-provider-specific logic behind a single
`generate_ai_response()` function, so the underlying provider can be
swapped later (Anthropic, OpenAI, local model, etc.) without touching
route code.

Configuration comes from environment variables:
    AI_API_KEY  -> secret key for the AI provider
    AI_MODEL    -> model name/identifier to use

If AI_API_KEY is not configured, a safe fallback response is returned
so the rest of the application (and demos) keep working.
"""

import os
import requests
from dotenv import load_dotenv
from sqlalchemy.orm import Session
from typing import Optional

from models.project import Project

load_dotenv()

AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "claude-sonnet-4-6")

# Anthropic Messages API endpoint (used only if AI_API_KEY is configured).
ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"


def _build_project_context(db: Session, project_id: Optional[int]) -> str:
    """Builds a short text summary of the project to give the AI context."""
    if not project_id:
        return "No specific project is attached to this conversation."

    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return "The referenced project could not be found."

    return (
        f"Project title: {project.title}\n"
        f"Domain: {project.domain or 'N/A'}\n"
        f"Status: {project.status.value}\n"
        f"Description: {project.description or 'N/A'}"
    )


def _call_anthropic(system_prompt: str, user_message: str) -> str:
    """Calls the Anthropic API. Raises on failure so caller can fall back."""
    headers = {
        "x-api-key": AI_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    body = {
        "model": AI_MODEL,
        "max_tokens": 800,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_message}],
    }
    response = requests.post(ANTHROPIC_API_URL, json=body, headers=headers, timeout=30)
    response.raise_for_status()
    data = response.json()

    text_parts = [
        block.get("text", "") for block in data.get("content", []) if block.get("type") == "text"
    ]
    return "".join(text_parts).strip() or "I couldn't generate a response. Please try again."


def generate_ai_response(db: Session, project_id: Optional[int], user_message: str) -> str:
    """
    Main entry point used by the /ai/chat route.
    Returns the AI's text response as a plain string.
    """
    project_context = _build_project_context(db, project_id)

    system_prompt = (
        "You are the AI assistant inside PROJECTHUB - AI, an academic project "
        "management system for a college minor project. Help students and "
        "faculty with project guidance, task suggestions, documentation "
        "guidance, progress insights, and general academic project questions. "
        "Be concise and practical.\n\n"
        f"Context about the current project:\n{project_context}"
    )

    if not AI_API_KEY:
        # Fallback so the endpoint remains fully functional without a key
        # configured (useful for local development / demos).
        return (
            "[AI service not configured] Set AI_API_KEY and AI_MODEL in your "
            ".env file to enable real AI responses. For now, here is a canned "
            f"tip based on your message: '{user_message.strip()[:200]}' — "
            "break your task into smaller sub-tasks, assign clear deadlines, "
            "and document your progress regularly."
        )

    try:
        return _call_anthropic(system_prompt, user_message)
    except Exception:
        return (
            "The AI service is temporarily unavailable. Please try again "
            "later, or contact your project administrator."
        )
