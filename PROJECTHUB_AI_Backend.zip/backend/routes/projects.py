from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.project import Project
from models.team import Team, TeamMember
from models.feedback import Feedback
from schemas.project import ProjectCreate, ProjectUpdate, ProjectOut
from schemas.team import TeamCreate, TeamMemberAdd, TeamOut
from schemas.feedback import FeedbackOut
from services.project_service import get_project_or_404, ensure_student_can_access_project
from utils.dependencies import get_current_user, require_role

router = APIRouter(tags=["Projects"])


def _check_project_access(db: Session, user: User, project: Project):
    """Students are restricted to their own/team projects; faculty & admin see all."""
    if user.role == RoleEnum.student:
        ensure_student_can_access_project(db, user, project)


@router.post("/projects", response_model=ProjectOut, status_code=201,
             summary="Create a new project (student)")
def create_project(
    payload: ProjectCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.student, RoleEnum.admin)),
):
    project = Project(**payload.model_dump(), created_by=current_user.id)
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


@router.get("/projects/{project_id}", response_model=ProjectOut, summary="Get a project's details")
def get_project(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    _check_project_access(db, current_user, project)
    return project


@router.put("/projects/{project_id}", response_model=ProjectOut, summary="Update a project")
def update_project(
    project_id: int,
    payload: ProjectUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    _check_project_access(db, current_user, project)

    if current_user.role == RoleEnum.student and project.created_by != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the project owner can update this project",
        )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(project, field, value)

    db.commit()
    db.refresh(project)
    return project


# ---------------------------------------------------------------- #
# Team management
# ---------------------------------------------------------------- #
@router.get("/projects/{project_id}/team", response_model=List[TeamOut], summary="View project team(s)")
def get_teams(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    _check_project_access(db, current_user, project)
    return db.query(Team).filter(Team.project_id == project_id).all()


@router.post("/projects/{project_id}/team", response_model=TeamOut, status_code=201,
             summary="Create a team for a project")
def create_team(
    project_id: int,
    payload: TeamCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.student, RoleEnum.admin)),
):
    project = get_project_or_404(db, project_id)
    if current_user.role == RoleEnum.student and project.created_by != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the project owner can create a team",
        )

    team = Team(project_id=project_id, team_name=payload.team_name)
    db.add(team)
    db.commit()
    db.refresh(team)
    return team


@router.post("/projects/{project_id}/team/{team_id}/members", status_code=201,
             summary="Add a member to a project team")
def add_team_member(
    project_id: int,
    team_id: int,
    payload: TeamMemberAdd,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.student, RoleEnum.admin)),
):
    project = get_project_or_404(db, project_id)
    team = db.query(Team).filter(Team.id == team_id, Team.project_id == project_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Team not found for this project")

    if current_user.role == RoleEnum.student and project.created_by != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only the project owner can manage team members",
        )

    member = db.query(User).filter(User.id == payload.user_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="User to add was not found")

    existing = db.query(TeamMember).filter(
        TeamMember.team_id == team_id, TeamMember.user_id == payload.user_id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="User is already a member of this team")

    team_member = TeamMember(team_id=team_id, user_id=payload.user_id, member_role=payload.member_role)
    db.add(team_member)
    db.commit()
    db.refresh(team_member)
    return {"message": "Member added successfully", "team_member_id": team_member.id}


# ---------------------------------------------------------------- #
# Feedback (read-only from the project side; faculty write via /faculty)
# ---------------------------------------------------------------- #
@router.get("/projects/{project_id}/feedback", response_model=List[FeedbackOut],
            summary="View faculty feedback for a project")
def get_project_feedback(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    _check_project_access(db, current_user, project)
    return db.query(Feedback).filter(Feedback.project_id == project_id).all()
