from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.project import Project, ProjectStatusEnum
from models.task import Task
from models.progress import Progress
from models.feedback import Feedback
from schemas.project import ProjectOut, ProjectUpdate
from schemas.task import TaskOut
from schemas.progress import ProgressOut
from schemas.feedback import FeedbackCreate, FeedbackOut
from services.project_service import get_project_or_404
from utils.dependencies import require_role

router = APIRouter(prefix="/faculty", tags=["Faculty"])


@router.get("/projects", response_model=List[ProjectOut], summary="View all projects (for review)")
def get_all_projects(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    return db.query(Project).all()


@router.get("/projects/{project_id}", response_model=ProjectOut, summary="View a project's details")
def get_project_detail(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    return get_project_or_404(db, project_id)


@router.get("/projects/{project_id}/progress", response_model=List[ProgressOut],
            summary="Monitor a project's progress")
def get_project_progress(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    get_project_or_404(db, project_id)
    return (
        db.query(Progress)
        .filter(Progress.project_id == project_id)
        .order_by(Progress.created_at.desc())
        .all()
    )


@router.get("/projects/{project_id}/tasks", response_model=List[TaskOut], summary="View a project's tasks")
def get_project_tasks(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    get_project_or_404(db, project_id)
    return db.query(Task).filter(Task.project_id == project_id).all()


@router.post("/projects/{project_id}/feedback", response_model=FeedbackOut, status_code=201,
             summary="Provide feedback on a project")
def give_feedback(
    project_id: int,
    payload: FeedbackCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    get_project_or_404(db, project_id)
    feedback = Feedback(
        project_id=project_id,
        faculty_id=current_user.id,
        feedback_text=payload.feedback_text,
        rating=payload.rating,
    )
    db.add(feedback)
    db.commit()
    db.refresh(feedback)
    return feedback


@router.put("/projects/{project_id}/evaluation", response_model=ProjectOut,
            summary="Evaluate/update a project's status (e.g. mark completed)")
def evaluate_project(
    project_id: int,
    payload: ProjectUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    project = get_project_or_404(db, project_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(project, field, value)
    db.commit()
    db.refresh(project)
    return project


@router.get("/dashboard", summary="Faculty dashboard summary")
def faculty_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.faculty, RoleEnum.admin)),
):
    projects = db.query(Project).all()
    project_ids = [p.id for p in projects]

    pending_reviews = (
        db.query(Project)
        .filter(Project.status == ProjectStatusEnum.active)
        .count()
    )

    recent_feedback = (
        db.query(Feedback)
        .filter(Feedback.faculty_id == current_user.id)
        .order_by(Feedback.created_at.desc())
        .limit(5)
        .all()
    )

    return {
        "assigned_projects": len(project_ids),
        "project_progress_overview": [
            {"project_id": p.id, "title": p.title, "status": p.status.value} for p in projects
        ],
        "pending_reviews": pending_reviews,
        "recent_feedback_activity": [
            {
                "project_id": f.project_id,
                "feedback_text": f.feedback_text,
                "rating": f.rating,
                "created_at": f.created_at,
            }
            for f in recent_feedback
        ],
    }
