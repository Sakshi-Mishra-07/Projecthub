from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.task import Task
from schemas.task import TaskCreate, TaskUpdate, TaskOut
from services.project_service import get_project_or_404, ensure_student_can_access_project
from services.task_service import get_task_or_404
from utils.dependencies import get_current_user

router = APIRouter(tags=["Tasks"])


@router.get("/projects/{project_id}/tasks", response_model=List[TaskOut], summary="List tasks for a project")
def list_tasks(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    if current_user.role == RoleEnum.student:
        ensure_student_can_access_project(db, current_user, project)
    return db.query(Task).filter(Task.project_id == project_id).all()


@router.post("/projects/{project_id}/tasks", response_model=TaskOut, status_code=201,
             summary="Create a task under a project")
def create_task(
    project_id: int,
    payload: TaskCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    if current_user.role == RoleEnum.student:
        ensure_student_can_access_project(db, current_user, project)

    task = Task(project_id=project_id, **payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


@router.put("/tasks/{task_id}", response_model=TaskOut, summary="Update a task (status, details, assignment)")
def update_task(
    task_id: int,
    payload: TaskUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    task = get_task_or_404(db, task_id)
    project = get_project_or_404(db, task.project_id)

    if current_user.role == RoleEnum.student:
        ensure_student_can_access_project(db, current_user, project)
        # Students may only update tasks assigned to them, unless they own the project
        if task.assigned_to != current_user.id and project.created_by != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only update tasks assigned to you",
            )

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(task, field, value)

    db.commit()
    db.refresh(task)
    return task
