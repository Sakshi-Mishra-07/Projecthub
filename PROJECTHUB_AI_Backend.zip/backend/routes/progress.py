from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.progress import Progress
from schemas.progress import ProgressCreate, ProgressOut
from services.project_service import get_project_or_404, ensure_student_can_access_project
from utils.dependencies import get_current_user

router = APIRouter(tags=["Progress"])


@router.put("/projects/{project_id}/progress", response_model=ProgressOut,
            summary="Log a new progress update for a project")
def update_progress(
    project_id: int,
    payload: ProgressCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    if current_user.role == RoleEnum.student:
        ensure_student_can_access_project(db, current_user, project)

    progress = Progress(
        project_id=project_id,
        task_id=payload.task_id,
        progress_percentage=payload.progress_percentage,
        status_update=payload.status_update,
        updated_by=current_user.id,
    )
    db.add(progress)
    db.commit()
    db.refresh(progress)
    return progress


@router.get("/projects/{project_id}/progress-history", response_model=List[ProgressOut],
            summary="View progress history for a project")
def get_progress_history(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    project = get_project_or_404(db, project_id)
    if current_user.role == RoleEnum.student:
        ensure_student_can_access_project(db, current_user, project)
    return (
        db.query(Progress)
        .filter(Progress.project_id == project_id)
        .order_by(Progress.created_at.desc())
        .all()
    )
