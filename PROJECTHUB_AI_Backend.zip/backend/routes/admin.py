from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.project import Project, ProjectStatusEnum
from schemas.user import UserOut, UserUpdateByAdmin
from schemas.project import ProjectOut
from utils.dependencies import require_role

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/users", response_model=List[UserOut], summary="View all users")
def get_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    return db.query(User).all()


@router.get("/projects", response_model=List[ProjectOut], summary="View all projects")
def get_projects(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    return db.query(Project).all()


@router.get("/statistics", summary="Overall system statistics")
def get_statistics(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    total_users = db.query(User).count()
    total_students = db.query(User).filter(User.role == RoleEnum.student).count()
    total_faculty = db.query(User).filter(User.role == RoleEnum.faculty).count()
    total_projects = db.query(Project).count()
    active_projects = db.query(Project).filter(Project.status == ProjectStatusEnum.active).count()
    completed_projects = db.query(Project).filter(Project.status == ProjectStatusEnum.completed).count()

    return {
        "total_users": total_users,
        "total_students": total_students,
        "total_faculty": total_faculty,
        "total_projects": total_projects,
        "active_projects": active_projects,
        "completed_projects": completed_projects,
    }


@router.put("/users/{user_id}", response_model=UserOut, summary="Update a user's name/role")
def update_user(
    user_id: int,
    payload: UserUpdateByAdmin,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return user


@router.delete("/users/{user_id}", status_code=204, summary="Delete a user")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    db.delete(user)
    db.commit()
    return None


@router.delete("/projects/{project_id}", status_code=204, summary="Delete a project")
def delete_project(
    project_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")
    db.delete(project)
    db.commit()
    return None


@router.get("/dashboard", summary="Admin dashboard summary")
def admin_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.admin)),
):
    total_users = db.query(User).count()
    total_students = db.query(User).filter(User.role == RoleEnum.student).count()
    total_faculty = db.query(User).filter(User.role == RoleEnum.faculty).count()
    total_projects = db.query(Project).count()
    active_projects = db.query(Project).filter(Project.status == ProjectStatusEnum.active).count()
    completed_projects = db.query(Project).filter(Project.status == ProjectStatusEnum.completed).count()

    return {
        "total_users": total_users,
        "total_students": total_students,
        "total_faculty": total_faculty,
        "total_projects": total_projects,
        "active_projects": active_projects,
        "completed_projects": completed_projects,
    }
