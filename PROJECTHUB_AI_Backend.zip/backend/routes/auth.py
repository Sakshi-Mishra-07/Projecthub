from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.connection import get_db
from schemas.auth import RegisterRequest, LoginRequest, TokenResponse, CurrentUserResponse
from schemas.user import UserOut
from services.auth_service import register_user, authenticate_user
from utils.dependencies import get_current_user
from models.user import User

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserOut, status_code=201,
             summary="Register a new user (student, faculty or admin)")
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    user = register_user(db, payload)
    return user


@router.post("/login", response_model=TokenResponse, summary="Login and receive a JWT access token")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    token = authenticate_user(db, payload)
    return TokenResponse(access_token=token)


@router.get("/me", response_model=CurrentUserResponse, summary="Get the currently authenticated user")
def me(current_user: User = Depends(get_current_user)):
    return current_user
