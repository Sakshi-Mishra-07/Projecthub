from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User
from models.ai_interaction import AIInteraction
from schemas.ai import AIChatRequest, AIChatResponse
from services.ai_service import generate_ai_response
from utils.dependencies import get_current_user

router = APIRouter(prefix="/ai", tags=["AI Assistance"])


@router.post("/chat", response_model=AIChatResponse, status_code=201,
             summary="Chat with the AI project assistant")
def ai_chat(
    payload: AIChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ai_response_text = generate_ai_response(db, payload.project_id, payload.message)

    interaction = AIInteraction(
        user_id=current_user.id,
        project_id=payload.project_id,
        user_message=payload.message,
        ai_response=ai_response_text,
    )
    db.add(interaction)
    db.commit()
    db.refresh(interaction)
    return interaction
