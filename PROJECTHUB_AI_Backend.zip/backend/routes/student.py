from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from database.connection import get_db
from models.user import User, RoleEnum
from models.project import Project
from models.team import Team, TeamMember
from models.task import Task, TaskStatusEnum
from models.feedback import Feedback
from schemas.user import UserOut
from schemas.project import ProjectOut
from utils.dependencies import get_current_user, require_role

router = APIRouter(prefix="/student", tags=["Student"])


def _student_project_ids(db: Session, user: User) -> List[int]:
    owned = db.query(Project.id).filter(Project.created_by == user.id)
    member_of = (
        db.query(Team.project_id)
        .join(TeamMember, TeamMember.team_id == Team.id)
        .filter(TeamMember.user_id == user.id)
    )
    ids = {row[0] for row in owned.all()} | {row[0] for row in member_of.all()}
    return list(ids)


@router.get("/profile", response_model=UserOut, summary="View own student profile")
def get_profile(current_user: User = Depends(require_role(RoleEnum.student))):
    return current_user


@router.get("/projects", response_model=List[ProjectOut], summary="View own project(s)")
def get_my_projects(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.student)),
):
    ids = _student_project_ids(db, current_user)
    if not ids:
        return []
    return db.query(Project).filter(Project.id.in_(ids)).all()


@router.get("/dashboard", summary="Student dashboard summary")
def student_dashboard(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(RoleEnum.student)),
):
    project_ids = _student_project_ids(db, current_user)

    total_tasks = db.query(Task).filter(Task.project_id.in_(project_ids)).count() if project_ids else 0
    completed_tasks = (
        db.query(Task)
        .filter(Task.project_id.in_(project_ids), Task.status == TaskStatusEnum.completed)
        .count()
        if project_ids
        else 0
    )
    pending_tasks = total_tasks - completed_tasks

    progress_percentage = round((completed_tasks / total_tasks) * 100, 2) if total_tasks else 0

    recent_feedback = (
        db.query(Feedback)
        .filter(Feedback.project_id.in_(project_ids))
        .order_by(Feedback.created_at.desc())
        .limit(5)
        .all()
        if project_ids
        else []
    )

    return {
        "projects": project_ids,
        "total_tasks": total_tasks,
        "completed_tasks": completed_tasks,
        "pending_tasks": pending_tasks,
        "progress_percentage": progress_percentage,
        "recent_feedback": [
            {
                "project_id": f.project_id,
                "feedback_text": f.feedback_text,
                "rating": f.rating,
                "created_at": f.created_at,
            }
            for f in recent_feedback
        ],
    }
