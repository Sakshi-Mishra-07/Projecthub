# PROJECTHUB – AI (Backend)

An academic project management backend built for a college minor project.
Provides secure REST APIs for **Students**, **Faculty**, and **Admins**,
plus an integrated AI assistance module.

## 1. Project Overview

PROJECTHUB – AI helps educational institutions manage academic projects:
project creation, team formation, task tracking, progress logging,
faculty feedback/evaluation, and an AI chat assistant for guidance —
all behind a role-based, JWT-secured REST API for a React + Vite frontend.

## 2. Technologies

- Python 3.11+
- FastAPI
- MySQL
- SQLAlchemy ORM
- Pydantic
- JWT (python-jose) authentication
- Passlib + bcrypt for password hashing
- Uvicorn (ASGI server)
- python-dotenv
- FastAPI CORS middleware

## 3. Folder Structure

```
backend/
├── main.py                  # FastAPI app entrypoint
├── requirements.txt
├── .env.example
├── schema.sql                # Reference MySQL schema (optional manual setup)
├── seed.py                   # Optional demo/seed data script
├── README.md
│
├── database/
│   ├── connection.py          # Engine, SessionLocal, get_db()
│   └── base.py                # SQLAlchemy declarative Base
│
├── models/                    # SQLAlchemy ORM models (one file per table)
├── schemas/                   # Pydantic request/response schemas
├── routes/                    # FastAPI routers (auth, student, faculty, admin, ...)
├── services/                  # Business logic (auth, project, task, AI)
└── utils/
    ├── security.py             # Password hashing + JWT
    └── dependencies.py         # get_current_user, require_role
```

## 4. MySQL Database Setup

1. Install and start MySQL (8.0+ recommended).
2. Create the database (the app can also auto-create tables on startup,
   but you must create the database itself first):

   ```sql
   CREATE DATABASE projecthub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

   Alternatively, run the full reference schema directly:

   ```bash
   mysql -u root -p < schema.sql
   ```

## 5. Environment Variables

Copy `.env.example` to `.env` and fill in real values:

```bash
cp .env.example .env
```

| Variable | Description |
|---|---|
| `DB_HOST` | MySQL host (e.g. `localhost`) |
| `DB_PORT` | MySQL port (default `3306`) |
| `DB_USER` | MySQL username |
| `DB_PASSWORD` | MySQL password |
| `DB_NAME` | Database name (`projecthub`) |
| `JWT_SECRET_KEY` | Long random secret used to sign JWTs |
| `JWT_ALGORITHM` | JWT signing algorithm (default `HS256`) |
| `JWT_EXPIRE_MINUTES` | Access token lifetime in minutes |
| `AI_API_KEY` | API key for the AI provider (optional for local dev) |
| `AI_MODEL` | AI model name to use |
| `FRONTEND_ORIGIN` | Allowed CORS origin for the React/Vite frontend |

**Never commit your real `.env` file.**

## 6. Installation

```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 7. Running the Backend

```bash
python -m uvicorn main:app --reload
```

The app automatically creates all required tables on startup
(`Base.metadata.create_all()`), so no manual migration step is required
for a fresh database.

Optionally load demo data:

```bash
python seed.py
```

This inserts 1 admin, 2 faculty, 5 students, 2 sample projects, teams,
tasks, progress and feedback records — all clearly marked as **DEMO**
data with no real personal information. Demo password for every seeded
user is `Demo@1234`.

## 8. Swagger / API Documentation

Once running, visit:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 9. API Modules

| Module | Prefix | Description |
|---|---|---|
| Auth | `/auth` | Register, login, current user |
| Student | `/student` | Profile, own projects, dashboard |
| Faculty | `/faculty` | Review projects, feedback, evaluation, dashboard |
| Admin | `/admin` | User/project management, statistics, dashboard |
| Projects | `/projects` | Create/view/update projects, teams, feedback |
| Tasks | `/projects/{id}/tasks`, `/tasks/{id}` | Task CRUD |
| Progress | `/projects/{id}/progress` | Progress logging |
| AI | `/ai/chat` | AI assistance, stored in `ai_interactions` |

All endpoints (except `/auth/register` and `/auth/login`) require a
`Authorization: Bearer <token>` header, obtained from `/auth/login`.

## 10. Seed Data

See section 7. The `seed.py` script is idempotent — safe to re-run;
it looks up existing seed users/projects by unique fields before
inserting.

## 11. Frontend Connection

From your React + Vite frontend, set the API base URL to your backend,
e.g. in a `.env` file for the frontend:

```
VITE_API_BASE_URL=http://localhost:8000
```

Ensure `FRONTEND_ORIGIN` in the backend `.env` matches your Vite dev
server URL (default `http://localhost:5173`) so CORS allows requests.

## 12. Common Errors & Solutions

| Error | Likely Cause | Fix |
|---|---|---|
| `Can't connect to MySQL server` | MySQL not running / wrong host-port | Check MySQL service is running and `.env` values |
| `Access denied for user` | Wrong `DB_USER`/`DB_PASSWORD` | Verify MySQL credentials |
| `Unknown database 'projecthub'` | Database not created | Run `CREATE DATABASE projecthub;` first |
| `401 Unauthorized` on protected routes | Missing/expired JWT | Login again via `/auth/login`, send `Authorization: Bearer <token>` |
| `403 Forbidden` | Wrong role for the endpoint | Use an account with the required role (student/faculty/admin) |
| `422 Unprocessable Entity` | Invalid request body | Check the request against the schema shown in `/docs` |
| AI chat returns a generic fallback message | `AI_API_KEY` not set in `.env` | Add a valid key and `AI_MODEL`, restart the server |

---
This backend is intended as a clean, understandable minor-project
reference implementation. It intentionally avoids unrelated features
(payments, IoT, marketplace, ML training pipelines, etc.) to stay
within the scope of a B.Tech 5th-semester minor project.
