import enum
from sqlalchemy import Column, Integer, String, Text, Date, DateTime, ForeignKey, Enum
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from database.base import Base


class ProjectStatusEnum(str, enum.Enum):
    proposed = "proposed"
    active = "active"
    on_hold = "on_hold"
    completed = "completed"


class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    domain = Column(String(120), nullable=True)
    status = Column(Enum(ProjectStatusEnum), nullable=False, default=ProjectStatusEnum.proposed, index=True)
    start_date = Column(Date, nullable=True)
    end_date = Column(Date, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    creator = relationship("User", back_populates="projects_created", foreign_keys=[created_by])
    teams = relationship("Team", back_populates="project", cascade="all, delete-orphan")
    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    progress_records = relationship("Progress", back_populates="project", cascade="all, delete-orphan")
    feedback_records = relationship("Feedback", back_populates="project", cascade="all, delete-orphan")
    ai_interactions = relationship("AIInteraction", back_populates="project")
