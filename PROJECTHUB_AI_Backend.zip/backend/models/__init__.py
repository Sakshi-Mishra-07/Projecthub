"""
Importing every model here ensures that Base.metadata.create_all()
(called from main.py) is aware of all tables, including relationships
that are only referenced by string name.
"""

from models.user import User
from models.project import Project
from models.team import Team, TeamMember
from models.task import Task
from models.progress import Progress
from models.feedback import Feedback
from models.ai_interaction import AIInteraction

__all__ = [
    "User",
    "Project",
    "Team",
    "TeamMember",
    "Task",
    "Progress",
    "Feedback",
    "AIInteraction",
]
