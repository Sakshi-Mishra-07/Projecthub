from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel


class TeamCreate(BaseModel):
    team_name: str


class TeamMemberAdd(BaseModel):
    user_id: int
    member_role: Optional[str] = "member"


class TeamMemberOut(BaseModel):
    id: int
    user_id: int
    member_role: str
    joined_at: datetime

    class Config:
        from_attributes = True


class TeamOut(BaseModel):
    id: int
    project_id: int
    team_name: str
    created_at: datetime
    members: List[TeamMemberOut] = []

    class Config:
        from_attributes = True
