from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class FeedbackCreate(BaseModel):
    feedback_text: str
    rating: Optional[int] = Field(None, ge=1, le=5)


class FeedbackUpdate(BaseModel):
    feedback_text: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)


class FeedbackOut(BaseModel):
    id: int
    project_id: int
    faculty_id: Optional[int]
    feedback_text: str
    rating: Optional[int]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
