from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from models.task import TaskStatusEnum, TaskPriorityEnum


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    assigned_to: Optional[int] = None
    priority: TaskPriorityEnum = TaskPriorityEnum.medium
    deadline: Optional[datetime] = None


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    assigned_to: Optional[int] = None
    status: Optional[TaskStatusEnum] = None
    priority: Optional[TaskPriorityEnum] = None
    deadline: Optional[datetime] = None


class TaskOut(BaseModel):
    id: int
    project_id: int
    assigned_to: Optional[int]
    title: str
    description: Optional[str]
    status: TaskStatusEnum
    priority: TaskPriorityEnum
    deadline: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
