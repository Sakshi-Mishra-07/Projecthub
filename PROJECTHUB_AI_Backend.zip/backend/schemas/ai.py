from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class AIChatRequest(BaseModel):
    project_id: Optional[int] = None
    message: str


class AIChatResponse(BaseModel):
    id: int
    user_id: int
    project_id: Optional[int]
    user_message: str
    ai_response: str
    created_at: datetime

    class Config:
        from_attributes = True
