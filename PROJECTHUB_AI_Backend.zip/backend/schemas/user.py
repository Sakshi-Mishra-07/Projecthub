from datetime import datetime
from pydantic import BaseModel, EmailStr
from typing import Optional
from models.user import RoleEnum


class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: RoleEnum
    created_at: datetime

    class Config:
        from_attributes = True


class UserUpdateByAdmin(BaseModel):
    name: Optional[str] = None
    role: Optional[RoleEnum] = None
