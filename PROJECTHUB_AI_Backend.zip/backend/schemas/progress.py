from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class ProgressCreate(BaseModel):
    task_id: Optional[int] = None
    progress_percentage: int = Field(..., ge=0, le=100)
    status_update: Optional[str] = None


class ProgressOut(BaseModel):
    id: int
    project_id: int
    task_id: Optional[int]
    progress_percentage: int
    status_update: Optional[str]
    updated_by: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True
