from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel
from models.project import ProjectStatusEnum


class ProjectCreate(BaseModel):
    title: str
    description: Optional[str] = None
    domain: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None


class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    domain: Optional[str] = None
    status: Optional[ProjectStatusEnum] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None


class ProjectOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    domain: Optional[str]
    status: ProjectStatusEnum
    start_date: Optional[date]
    end_date: Optional[date]
    created_by: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
