"""
DEMO / SEED DATA SCRIPT for PROJECTHUB - AI
--------------------------------------------
This script inserts sample academic data so the app can be demoed
immediately. All data below is fictional (no real personal info).

Run with:
    python seed.py

Safe to re-run: it checks for existing seed users by email before
inserting, so it will not create duplicates.
"""

from datetime import date, datetime, timedelta

from database.connection import SessionLocal, engine
from database.base import Base
import models  # noqa: F401
from models.user import User, RoleEnum
from models.project import Project, ProjectStatusEnum
from models.team import Team, TeamMember
from models.task import Task, TaskStatusEnum, TaskPriorityEnum
from models.progress import Progress
from models.feedback import Feedback
from utils.security import hash_password

Base.metadata.create_all(bind=engine)

db = SessionLocal()


def get_or_create_user(name, email, role, password="Demo@1234"):
    user = db.query(User).filter(User.email == email).first()
    if user:
        return user
    user = User(name=name, email=email, password_hash=hash_password(password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def run():
    print("Seeding DEMO data for PROJECTHUB - AI ...")

    # ---- Users ----
    admin = get_or_create_user("Demo Admin", "admin@demo.projecthub.edu", RoleEnum.admin)
    faculty1 = get_or_create_user("Dr. Asha Rao", "asha.rao@demo.projecthub.edu", RoleEnum.faculty)
    faculty2 = get_or_create_user("Dr. Vikram Sen", "vikram.sen@demo.projecthub.edu", RoleEnum.faculty)

    student1 = get_or_create_user("Aarav Sharma", "aarav.sharma@demo.projecthub.edu", RoleEnum.student)
    student2 = get_or_create_user("Diya Patel", "diya.patel@demo.projecthub.edu", RoleEnum.student)
    student3 = get_or_create_user("Rohan Gupta", "rohan.gupta@demo.projecthub.edu", RoleEnum.student)
    student4 = get_or_create_user("Isha Verma", "isha.verma@demo.projecthub.edu", RoleEnum.student)
    student5 = get_or_create_user("Karan Mehta", "karan.mehta@demo.projecthub.edu", RoleEnum.student)

    # ---- Projects ----
    if not db.query(Project).filter(Project.title == "Smart Attendance System (DEMO)").first():
        project1 = Project(
            title="Smart Attendance System (DEMO)",
            description="A face-recognition based attendance tracker for classrooms.",
            domain="Computer Vision",
            status=ProjectStatusEnum.active,
            start_date=date.today() - timedelta(days=30),
            end_date=date.today() + timedelta(days=60),
            created_by=student1.id,
        )
        project2 = Project(
            title="Campus Event Portal (DEMO)",
            description="A web portal for managing and registering for campus events.",
            domain="Web Development",
            status=ProjectStatusEnum.proposed,
            start_date=date.today() - timedelta(days=10),
            end_date=date.today() + timedelta(days=80),
            created_by=student4.id,
        )
        db.add_all([project1, project2])
        db.commit()
        db.refresh(project1)
        db.refresh(project2)

        # ---- Teams ----
        team1 = Team(project_id=project1.id, team_name="Team Vision")
        team2 = Team(project_id=project2.id, team_name="Team Portal")
        db.add_all([team1, team2])
        db.commit()
        db.refresh(team1)
        db.refresh(team2)

        db.add_all([
            TeamMember(team_id=team1.id, user_id=student1.id, member_role="leader"),
            TeamMember(team_id=team1.id, user_id=student2.id, member_role="member"),
            TeamMember(team_id=team1.id, user_id=student3.id, member_role="member"),
            TeamMember(team_id=team2.id, user_id=student4.id, member_role="leader"),
            TeamMember(team_id=team2.id, user_id=student5.id, member_role="member"),
        ])
        db.commit()

        # ---- Tasks ----
        task1 = Task(
            project_id=project1.id, assigned_to=student1.id,
            title="Design database schema", description="Design ER diagram for attendance data.",
            status=TaskStatusEnum.completed, priority=TaskPriorityEnum.high,
            deadline=datetime.now() - timedelta(days=20),
        )
        task2 = Task(
            project_id=project1.id, assigned_to=student2.id,
            title="Implement face detection module", description="Integrate OpenCV face detection.",
            status=TaskStatusEnum.in_progress, priority=TaskPriorityEnum.high,
            deadline=datetime.now() + timedelta(days=10),
        )
        task3 = Task(
            project_id=project1.id, assigned_to=student3.id,
            title="Build attendance report UI", description="React page to view attendance reports.",
            status=TaskStatusEnum.pending, priority=TaskPriorityEnum.medium,
            deadline=datetime.now() + timedelta(days=20),
        )
        task4 = Task(
            project_id=project2.id, assigned_to=student4.id,
            title="Design event registration form", description="Frontend form for event sign-ups.",
            status=TaskStatusEnum.pending, priority=TaskPriorityEnum.medium,
            deadline=datetime.now() + timedelta(days=15),
        )
        db.add_all([task1, task2, task3, task4])
        db.commit()
        db.refresh(task1)
        db.refresh(task2)

        # ---- Progress ----
        db.add_all([
            Progress(project_id=project1.id, task_id=task1.id, progress_percentage=100,
                     status_update="Schema finalized and reviewed.", updated_by=student1.id),
            Progress(project_id=project1.id, task_id=task2.id, progress_percentage=40,
                     status_update="Face detection working on sample dataset.", updated_by=student2.id),
            Progress(project_id=project2.id, task_id=task4.id, progress_percentage=10,
                     status_update="Wireframe created for registration form.", updated_by=student4.id),
        ])

        # ---- Feedback ----
        db.add_all([
            Feedback(project_id=project1.id, faculty_id=faculty1.id,
                     feedback_text="Good progress on the schema design. Proceed with the detection module.",
                     rating=4),
            Feedback(project_id=project2.id, faculty_id=faculty2.id,
                     feedback_text="Please finalize the tech stack before the next review.",
                     rating=3),
        ])
        db.commit()

    print("Seeding complete.")
    print("Demo login (all users): password = Demo@1234")
    print(f"  Admin:    {admin.email}")
    print(f"  Faculty:  {faculty1.email}, {faculty2.email}")
    print(f"  Students: {student1.email}, {student2.email}, {student3.email}, {student4.email}, {student5.email}")


if __name__ == "__main__":
    try:
        run()
    finally:
        db.close()
